package helloWorld.HelloWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
